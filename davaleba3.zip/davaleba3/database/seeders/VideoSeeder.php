<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Video;
use Illuminate\Support\Facades\DB;

class VideoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('videos')->insert(
        [
            "name" => "Me at the zoo",
            "link" => "https://www.youtube.com/watch?v=jNQXAC9IVRw",
            "description" => "First video on Youtube",
            "upload-date" => '2005-04-23',
        ]
    );
    }
}
